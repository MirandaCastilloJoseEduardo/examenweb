    <div class="modal fade" id="eliminarPrdoct" tabindex="-1" role="dialog" aria-labelledby="eliminarPrdoct" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h4 class="modal-title text-center">Eliminar Producto</h4>
                </div>
                <div class="modal-body text-center" style="border-bottom:1px solid #e9ecef;">
                    <label style="color: #333; font-weight:600;">
                        ¿Estás seguro de eliminar el Producto?
                    </label>
                </div>

                <div class="modal-body text-center">
                    <button id="btnYesEliminarProduct" onclick="yesEliminarProducto(this)" class="btn btn-primary yesDelete" data-dismiss="modal">Sí</button>
                    <button class="btn btn-danger noDelete" data-dismiss="modal">No</button>
                </div>
            </div>
        </div>
    </div>